$(document).ready(function(e) {
   $("#progressTimer").progressTimer({

    timeLimit: 6,

    warningThreshold: 10,

    baseStyle: 'progress-bar-info',

    warningStyle: 'progress-bar-info',

    completeStyle: 'progress-bar-info',

    onFinish: function() {
		

        console.log("I'm done");
		

    }
	

});
 
});

$('.navbar-brand').tooltip({

placement:'bottom'
	
})

